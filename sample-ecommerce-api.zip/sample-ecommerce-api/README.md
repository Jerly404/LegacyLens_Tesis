# E-Commerce Order Management Microservice

Enterprise order fulfillment service connecting REST clients, PostgreSQL data storage, and legacy inventory ledgers.

## Architecture
- **Framework**: Java 11 / Spring Boot 2.7.5 & Spring Data JPA
- **Database**: PostgreSQL 16
- **Architecture Pattern**: Layered Architecture (Controllers -> Services -> Repositories -> Models)

## Key Endpoints
- `POST /api/v1/orders/checkout` : Process new customer checkout and total calculation
- `GET /api/v1/orders/{orderId}` : Retrieve order details
- `GET /api/v1/orders/customer/{customerId}` : Query order history for a customer
